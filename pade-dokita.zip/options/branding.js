var branding = {
    pade_enable_converse         : {disable: true, value: false}, 
    pade_server_url              : {disable: true, value: "https://pade.chat:5443"},
    pade_access_token            : {disable: true, value: "dummy_value"},	
    pade_domain		             : {disable: true, value: "pade.chat"},		
    pade_username	             : {disable: true, value: "dummy_value"},	
    pade_name		             : {disable: true, value: "dummy_value"},			
    pade_email		             : {disable: true, value: "dummy_value"},		
}