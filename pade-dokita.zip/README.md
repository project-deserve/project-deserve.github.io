# ![IMAGE](https://github.com/project-deserve/pade-dokita/blob/main/img/logo_32.png?raw=true) Pàdé  Dokita
Browser Extension to customize Github and integrate a Project Deserve clinic with Pàdé 
